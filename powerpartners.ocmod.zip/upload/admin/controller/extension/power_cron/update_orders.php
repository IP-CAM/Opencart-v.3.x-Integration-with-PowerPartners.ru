<?php
	$cli_action = 'extension/module/power/update_orders';
	require_once('cli_dispatch.php'); 
	
	// 0 1 0 0 0 /path/to/php /path/to/opencart/cli/cli_some_function.php)
?>